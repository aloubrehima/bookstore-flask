#!/usr/bin/env python3


import sys
import os
sys.path.append('.')

from app import timeit_and_log, log_event
import time
import sqlite3

@timeit_and_log
def fast_function():
    """A fast function for testing."""
    time.sleep(0.01)
    return "Fast result"

@timeit_and_log
def slow_function():
    """A slower function for testing."""
    time.sleep(0.1)
    return "Slow result"

@timeit_and_log
def error_function():
    """A function that raises an error."""
    time.sleep(0.05)
    raise RuntimeError("This is a test error")

def run_tests():
    print("Testing execution time logging functionality...")
    
    # Test successful functions
    print("\n1. Testing fast function...")
    result1 = fast_function()
    print(f"Result: {result1}")
    
    print("\n2. Testing slow function...")
    result2 = slow_function()
    print(f"Result: {result2}")
    
    # Test error function
    print("\n3. Testing error function...")
    try:
        error_function()
    except RuntimeError as e:
        print(f"Caught expected error: {e}")
    
    # Query and display recent logs
    print("\n4. Recent log entries:")
    conn = sqlite3.connect('db/books.db')
    cursor = conn.cursor()
    cursor.execute("""
        SELECT timestamp, level, message, execution_time 
        FROM Logs 
        ORDER BY log_id DESC 
        LIMIT 10
    """)
    
    for row in cursor.fetchall():
        timestamp, level, message, exec_time = row
        exec_time_str = f"{exec_time:.4f}s" if exec_time else "N/A"
        print(f"  {timestamp[:19]} | {level:5} | {message[:50]:50} | {exec_time_str}")
    
    conn.close()
    print("\nTest completed!")

if __name__ == "__main__":
    run_tests()