from flask import Flask, jsonify, render_template, request
import sqlite3
import pymongo
from bson import ObjectId
from datetime import datetime
import time
import functools

app = Flask(__name__)

# Define the path to your SQLite database file
DATABASE = 'db/books.db'

# MongoDB connection
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client['book_database']  # MongoDB database
reviews_collection = db['reviews']  # MongoDB collection for reviews

# -----------------------------
# Function to log events/errors
# -----------------------------

def get_db_connection():
    return sqlite3.connect(DATABASE)

def log_event(level, message, details=None, execution_time=None):
    """Insert a log entry into the Logs table."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO Logs (timestamp, level, message, details, execution_time)
            VALUES (?, ?, ?, ?, ?)
            """,
            (datetime.utcnow().isoformat(), level, message, details, execution_time)
        )
        conn.commit()
        conn.close()
    except Exception as e:
        # Fallback: print to console if logging fails
        print("Logging failed:", e)


def timeit_and_log(func):
    """Decorator to measure execution time and log function calls."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        func_name = func.__name__
        t1 = time.time()
        
        try:
            # Log function start
            log_event('INFO', f'{func_name}() called', f'Starting execution of {func_name}')
            
            # Execute the function
            result = func(*args, **kwargs)
            
            # Calculate execution time
            t2 = time.time()
            delta_t = t2 - t1
            
            # Log successful completion with execution time
            log_event('INFO', f'{func_name}() completed successfully', 
                     f'Function executed successfully', delta_t)
            
            return result
            
        except Exception as e:
            # Calculate execution time even for errors
            t2 = time.time()
            delta_t = t2 - t1
            
            # Log error without execution time (as requested)
            log_event('ERROR', f'{func_name}() failed', str(e))
            
            # Re-raise the exception
            raise
    
    return wrapper


def ensure_author_column():
    """Ensure the Books table has an 'author' column. Adds it if missing."""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("PRAGMA table_info('Books')")
    cols = [row[1] for row in cursor.fetchall()]
    if 'author' not in cols:
        cursor.execute("ALTER TABLE Books ADD COLUMN author TEXT")
        conn.commit()

    if 'image_url' not in cols:
        cursor.execute("ALTER TABLE Books ADD COLUMN image_url TEXT")
        conn.commit()
    conn.close()

ensure_author_column()

@app.route('/api/books', methods=['GET'])
@timeit_and_log
def get_all_books():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT book_id, title, publication_year, image_url, author FROM Books")
    books = cursor.fetchall()
    conn.close()

    book_list = []
    for book in books:
        book_dict = {
            'book_id': book[0],
            'title': book[1],
            'publication_year': book[2],
            'image_url': book[3] if len(book) > 3 else None,
            'author': book[4] if len(book) > 4 else None
        }
        book_list.append(book_dict)

    return jsonify({'books': book_list})


# API to get all authors
@app.route('/api/authors', methods=['GET'])
@timeit_and_log
def get_all_authors():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Authors")
    authors = cursor.fetchall()
    conn.close()
    return jsonify(authors)

# API to get all reviews
@app.route('/api/reviews_sqlite', methods=['GET'])
@timeit_and_log
def get_all_reviews_sqlite():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Reviews")
    reviews = cursor.fetchall()
    conn.close()
    return jsonify(reviews)

# API to add a book to the database
@app.route('/api/add_book', methods=['POST'])
@timeit_and_log
def add_book():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # Get book details from the request
    data = request.get_json()
    title = data.get('title')
    publication_year = data.get('publication_year')
    author = data.get('author')
    image_url = data.get('image_url')

    # Insert the book into the database 
    cursor.execute("INSERT INTO Books (title, publication_year, image_url, author) VALUES (?, ?, ?, ?)", (title, publication_year, image_url, author))
    conn.commit()
    conn.close()

    return jsonify({'message': 'Book added successfully'})


@app.route('/api/delete_book/<int:book_id>', methods=['DELETE'])
@timeit_and_log
def delete_book(book_id):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM Books WHERE book_id = ?", (book_id,))
    count = cursor.fetchone()[0]
    if count == 0:
        conn.close()
        return jsonify({'error': 'Book not found'}), 404

    cursor.execute("DELETE FROM Books WHERE book_id = ?", (book_id,))
    conn.commit()
    conn.close()

    return jsonify({'message': 'Book deleted successfully'})

# API to search for books by title or author
@app.route('/api/search', methods=['GET'])
@timeit_and_log
def search_books():
    query = request.args.get('q', '')

    if not query:
        return jsonify({'error': 'No search query provided'}), 400

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT book_id, title, publication_year, image_url, author 
        FROM Books 
        WHERE LOWER(title) LIKE ? OR LOWER(author) LIKE ?
    """, ('%' + query.lower() + '%', '%' + query.lower() + '%'))
    results = cursor.fetchall()
    conn.close()

    # Format results as JSON with all book details
    books = []
    for row in results:
        book_dict = {
            'book_id': row[0],
            'title': row[1],
            'publication_year': row[2],
            'image_url': row[3],
            'author': row[4]
        }
        books.append(book_dict)

    return jsonify({'results': books})

# API to get all reviews from MongoDB
@app.route('/api/reviews', methods=['GET'])
@timeit_and_log
def get_all_reviews():
    cursor = reviews_collection.find({})
    reviews = []
    for doc in cursor:
        reviews.append({
            'id': str(doc.get('_id')),
            'book_id': doc.get('book_id'),
            'user': doc.get('user'),
            'rating': doc.get('rating'),
            'comment': doc.get('comment')
        })
    return jsonify({'reviews': reviews})

@app.route('/api/add_review', methods=['POST'])
@timeit_and_log
def add_review():
    data = request.get_json()  # Get review details from the request
    book_id = data.get('book_id')
    user = data.get('user')
    rating = data.get('rating')
    comment = data.get('comment')

    # Insert the review into the MongoDB collection
    review = {
        'book_id': book_id,
        'user': user,
        'rating': rating,
        'comment': comment
    }
    result = reviews_collection.insert_one(review)

    return jsonify({'message': 'Review added successfully', 'id': str(result.inserted_id)})

# API to delete a review by its MongoDB _id
@app.route('/api/reviews/<review_id>', methods=['DELETE'])
@timeit_and_log
def delete_review(review_id):
    try:
        oid = ObjectId(review_id)
    except Exception:
        return jsonify({'error': 'Invalid review id'}), 400

    result = reviews_collection.delete_one({'_id': oid})
    if result.deleted_count == 0:
        return jsonify({'error': 'Review not found'}), 404
    
    return jsonify({'message': 'Review deleted successfully'})

# Route to render the index.html page
@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0")
