// Array to store book data
const books = [];

function addBook() {
    const bookTitle = document.getElementById('bookTitle').value;
    const publicationYear = document.getElementById('publicationYear').value;
    const authorName = document.getElementById('authorName') ? document.getElementById('authorName').value : null;
    const imageUrl = document.getElementById('imageUrl') ? document.getElementById('imageUrl').value : null;

    const bookData = {
        title: bookTitle,
        publication_year: publicationYear,
        author: authorName,
        image_url: imageUrl
    };

    fetch('/api/add_book', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(bookData)
    })
        .then(response => response.json())
        .then(data => {
            console.log(data.message);
                showAllBooks();
                document.getElementById('bookTitle').value = '';
                document.getElementById('publicationYear').value = '';
                if (document.getElementById('authorName')) document.getElementById('authorName').value = '';
                if (document.getElementById('imageUrl')) document.getElementById('imageUrl').value = '';
        })
        .catch(error => {
            console.error('Error adding book:', error);
        });
}

function displayBooks() {
    const bookList = document.getElementById('bookList');
    bookList.innerHTML = '';

    books.forEach(book => {
        const bookElement = document.createElement('div');
        bookElement.innerHTML = `
            <h2>Added Successfully :${book.title}</h2>
            <p>Publication Year: ${book.publication_year}</p>
        `;
        bookList.appendChild(bookElement);
    });
}

function showAllBooks() {
    fetch('/api/books')
        .then(response => response.json())
        .then(data => {
            const bookList = document.getElementById('allbooks');
            bookList.innerHTML = ''; 
            console.log(data)
            data.books.forEach(book => { 
                const bookCard = document.createElement('div');
                bookCard.className = 'book-card';

                if (book.image_url) console.log('Rendering image for', book.title, book.image_url);

                const imgTag = book.image_url
                    ? `<img src="${book.image_url}" alt="${book.title}" onerror="this.onerror=null;this.src='https://via.placeholder.com/300?text=No+Image';">`
                    : `<div class="placeholder-img"></div>`;

                bookCard.innerHTML = `
                    ${imgTag}
                    <h3>${book.title}</h3>
                    <div class="book-meta">${book.author ? book.author : 'Unknown author'} • ${book.publication_year || 'N/A'}</div>
                    <div class="book-actions">
                        <button class="btn btn-delete" data-id="${book.book_id}">Delete</button>
                    </div>
                `;

                bookCard.querySelector('.btn-delete').addEventListener('click', (e) => {
                    const id = e.target.getAttribute('data-id');
                    if (confirm('Are you sure you want to delete this book?')) {
                        deleteBook(id);
                    }
                });

                bookList.appendChild(bookCard);
            });
        })
        .catch(error => {
            console.error('Error fetching all books:', error);
        });
}

// Function to add a review
function addReview() {
    const bookId = document.getElementById('bookId').value;
    const userName = document.getElementById('userName').value;
    const rating = document.getElementById('rating').value;
    const comment = document.getElementById('comment').value;

    const reviewData = {
        book_id: bookId,
        user: userName,
        rating: rating,
        comment: comment
    };

    fetch('/api/add_review', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(reviewData)
    })
        .then(response => response.json())
        .then(data => {
            console.log(data.message);
            showAllReviews();  // Refresh reviews after adding
        })
        .catch(error => {
            console.error('Error adding review:', error);
        });
}

// Function to fetch and display all reviews
function showAllReviews() {
    fetch('/api/reviews')
        .then(response => response.json())
        .then(data => {
            const reviewList = document.getElementById('reviewList');
            reviewList.innerHTML = '';  // Clear existing reviews

            data.reviews.forEach(review => {
                const reviewElement = document.createElement('div');
                reviewElement.classList.add('review');
                reviewElement.innerHTML = `
                    <h3>Book ID: ${review.book_id}</h3>
                    <p>User: ${review.user}</p>
                    <p>Rating: ${review.rating}</p>
                    <p>Comment: ${review.comment}</p>
                    <div class="review-actions">
                        <button class="btn btn-delete-review" data-id="${review.id}">Delete</button>
                    </div>
                `;
                const delBtn = reviewElement.querySelector('.btn-delete-review');
                if (delBtn && review.id) {
                    delBtn.addEventListener('click', () => deleteReview(review.id));
                }
                reviewList.appendChild(reviewElement);
            });
        })
        .catch(error => {
            console.error('Error fetching reviews:', error);
        });
}

function deleteReview(reviewId) {
    if (!reviewId) {
        alert('Missing review id');
        return;
    }
    if (!confirm('Delete this review?')) return;

    fetch(`/api/reviews/${encodeURIComponent(reviewId)}`, {
        method: 'DELETE'
    })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('Error deleting review: ' + data.error);
                return;
            }
            showAllReviews();
        })
        .catch(error => {
            console.error('Error deleting review:', error);
            alert('Error deleting review');
        });
}

function deleteBook(bookId) {
    fetch(`/api/delete_book/${encodeURIComponent(bookId)}`, {
        method: 'DELETE'
    })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('Error deleting book: ' + data.error);
                return;
            }
            showAllBooks();
        })
        .catch(error => {
            console.error('Error deleting book:', error);
            alert('Error deleting book. See console for details.');
        });
}

function searchBooks() {
    const query = document.getElementById('searchBox').value;

    if (!query) {
        alert("Please enter a search term!");
        return;
    }

    fetch(`/api/search?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            const searchResults = document.getElementById('searchResults');
            searchResults.innerHTML = ''; 

            if (data.results && data.results.length > 0) {
                
                searchResults.innerHTML = '<h2>Search Results:</h2>';
                const resultsContainer = document.createElement('div');
                resultsContainer.className = 'search-results-grid';
                
                data.results.forEach(book => {
                    const bookCard = document.createElement('div');
                    bookCard.className = 'book-card search-result-card';

                    const imgTag = book.image_url
                        ? `<img src="${book.image_url}" alt="${book.title}" onerror="this.onerror=null;this.src='https://via.placeholder.com/300?text=No+Image';">`
                        : `<div class="placeholder-img"></div>`;

                    bookCard.innerHTML = `
                        ${imgTag}
                        <h3>${book.title}</h3>
                        <div class="book-meta">${book.author ? book.author : 'Unknown author'} • ${book.publication_year || 'N/A'}</div>
                    `;
                    resultsContainer.appendChild(bookCard);
                });
                
                searchResults.appendChild(resultsContainer);
            } else {
                searchResults.innerHTML = `<h2>Search Results:</h2><p>No matching books found.</p>`;
            }
        })
        .catch(error => {
            console.error('Error searching books:', error);
        });
}

document.addEventListener("DOMContentLoaded", () => {
    const searchButton = document.getElementById("searchButton");
    if (searchButton) {
        searchButton.addEventListener("click", searchBooks);
    }
});


