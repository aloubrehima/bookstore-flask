#!/usr/bin/env python3


import sys
sys.path.append('.')

def test_mongodb_reviews():
    print("=== Testing MongoDB Review Operations ===\n")
    
    from app import app
    import json
    
    app.config['TESTING'] = True
    
    with app.test_client() as client:
        print("1. Testing GET /api/reviews (MongoDB)...")
        response = client.get('/api/reviews')
        print(f"   Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.get_json()
            reviews = data.get('reviews', [])
            print(f"   Retrieved {len(reviews)} MongoDB reviews")
        else:
            print(f"   Error or MongoDB not available: {response.get_json()}")
        
        print("\n2. Testing POST /api/add_review...")
        test_review = {
            "book_id": 1,
            "user": "Test User",
            "rating": 5,
            "comment": "Great book for testing logging!"
        }
        
        response = client.post('/api/add_review', 
                             data=json.dumps(test_review),
                             content_type='application/json')
        print(f"   Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.get_json()
            print(f"   Response: {data}")
            review_id = data.get('id')
            
            if review_id:
                print(f"\n3. Testing DELETE /api/reviews/{review_id}...")
                response = client.delete(f'/api/reviews/{review_id}')
                print(f"   Status: {response.status_code}")
                print(f"   Response: {response.get_json()}")
        else:
            print(f"   Error or MongoDB not available: {response.get_json()}")

def check_recent_logs():
    """Check the most recent log entries"""
    import sqlite3
    
    print("\n=== Recent Log Entries After MongoDB Tests ===\n")
    
    conn = sqlite3.connect('db/books.db')
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT timestamp, level, message, execution_time 
        FROM Logs 
        ORDER BY log_id DESC 
        LIMIT 8
    """)
    
    logs = cursor.fetchall()
    
    for log in logs:
        timestamp, level, message, exec_time = log
        exec_time_str = f"{exec_time:.4f}s" if exec_time else "N/A"
        timestamp_short = timestamp[:19] if timestamp else "N/A"
        print(f"{timestamp_short} | {level:5} | {message:50} | {exec_time_str}")
    
    conn.close()

if __name__ == "__main__":
    test_mongodb_reviews()
    check_recent_logs()