import unittest
import json
import os
import sqlite3
import tempfile
import pymongo
from app import app

class BookShelfIntegrationTests(unittest.TestCase):

    def setUp(self):
        """Set up test environment before each test"""
        # Create a temporary database for testing
        self.test_db_fd, self.test_db_path = tempfile.mkstemp()
        app.config['TESTING'] = True
        
        # Update the DATABASE path in app module for testing
        import app as app_module
        self.original_db = app_module.DATABASE
        app_module.DATABASE = self.test_db_path
        
        self.client = app.test_client()
        
        # Initialize test database with proper schema
        self.init_test_database()

    def tearDown(self):
        """Clean up after each test"""
        os.close(self.test_db_fd)
        os.unlink(self.test_db_path)
        
        # Restore original database path
        import app as app_module
        app_module.DATABASE = self.original_db

    def init_test_database(self):
        """Initialize the test database with the Books table"""
        conn = sqlite3.connect(self.test_db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE Books (
                book_id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                publication_year INTEGER,
                image_url TEXT,
                author TEXT
            )
        ''')
        
        # Add some test books
        test_books = [
            ('Clean Code', 2008, 'https://example.com/clean-code.jpg', 'Robert C. Martin'),
            ('Atomic Habits', 2018, 'https://example.com/atomic-habits.jpg', 'James Clear'),
            ('The Pragmatic Programmer', 1999, 'https://example.com/pragmatic.jpg', 'David Thomas')
        ]
        
        cursor.executemany(
            'INSERT INTO Books (title, publication_year, image_url, author) VALUES (?, ?, ?, ?)',
            test_books
        )
        conn.commit()
        conn.close()

    def test_search_by_title_returns_correct_results(self):
        """Test searching by title returns correct results"""
        response = self.client.get('/api/search?q=Clean')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(len(data['results']), 1)
        self.assertEqual(data['results'][0]['title'], 'Clean Code')
        self.assertEqual(data['results'][0]['author'], 'Robert C. Martin')

    def test_search_by_author_returns_correct_results(self):
        """Test searching by author returns correct results"""
        response = self.client.get('/api/search?q=James')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(len(data['results']), 1)
        self.assertEqual(data['results'][0]['title'], 'Atomic Habits')
        self.assertEqual(data['results'][0]['author'], 'James Clear')

    def test_search_for_nonexistent_term_returns_empty_result(self):
        """Test searching for non-existent terms returns empty result"""
        response = self.client.get('/api/search?q=NonexistentBook')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(len(data['results']), 0)

    def test_add_book_persists_title_author_image(self):
        """Test adding a book persists title, author, and image_url and is returned by /api/books"""
        payload = {
            'title': 'Deep Work',
            'author': 'Cal Newport',
            'image_url': 'https://example.com/deep-work.jpg',
            'publication_year': 2016
        }

        # Add the book via API
        res = self.client.post('/api/add_book', data=json.dumps(payload), content_type='application/json')
        self.assertEqual(res.status_code, 200)

        # Fetch all books and verify the newly added book exists with all fields
        res = self.client.get('/api/books')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)

        match = next((b for b in data['books'] if b['title'] == 'Deep Work'), None)
        self.assertIsNotNone(match, 'Added book not found in /api/books response')
        self.assertEqual(match['author'], 'Cal Newport')
        self.assertEqual(match['image_url'], 'https://example.com/deep-work.jpg')
        self.assertEqual(match['publication_year'], 2016)

class TestMongoReviews(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Try to connect to MongoDB
        try:
            cls.client = pymongo.MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=500)
            cls.client.admin.command("ping")
        except Exception as e:
            raise unittest.SkipTest(f"MongoDB not available: {e}")

        cls.db = cls.client["book_database_test"]
        cls.collection = cls.db["reviews_test"]
        cls.collection.delete_many({})

        app.config["TESTING"] = True
        cls.app = app.test_client()

    def test_add_and_retrieve_reviews(self):
        # Add a review
        review = {
            "book_id": "b1",
            "user": "Alice",
            "rating": 5,
            "comment": "Amazing!"
        }
        res = self.app.post("/api/add_review", data=json.dumps(review), content_type="application/json")
        self.assertEqual(res.status_code, 200)

        # Retrieve all reviews
        res = self.app.get("/api/reviews")
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(any(r["user"] == "Alice" and r["comment"] == "Amazing!" for r in data["reviews"]))

    @classmethod
    def tearDownClass(cls):
        cls.db.drop_collection("reviews_test")
        cls.client.close()  

if __name__ == '__main__':
    # Run the tests
    unittest.main(verbosity=2)